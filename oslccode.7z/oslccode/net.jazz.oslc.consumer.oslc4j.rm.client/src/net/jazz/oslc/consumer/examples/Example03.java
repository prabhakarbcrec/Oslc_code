/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2013,2016. All Rights Reserved. 
 * 
 * Note to U.S. Government Users Restricted Rights:  Use, 
 * duplication or disclosure restricted by GSA ADP Schedule 
 * Contract with IBM Corp.
 *******************************************************************************/
package net.jazz.oslc.consumer.examples;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import net.jazz.oslc.rm.datamodel.Folder;
import net.jazz.oslc.utils.HttpUtils;
import net.oauth.OAuthException;

import org.apache.http.auth.InvalidCredentialsException;
import org.apache.http.client.HttpResponseException;
import org.apache.wink.client.ClientResponse;
import org.eclipse.lyo.client.exception.RootServicesException;
import org.eclipse.lyo.client.oslc.OAuthRedirectException;
import org.eclipse.lyo.client.oslc.OSLCConstants;
import org.eclipse.lyo.client.oslc.OslcOAuthClient;
import org.eclipse.lyo.client.oslc.jazz.JazzRootServicesHelper;
import org.eclipse.lyo.client.oslc.resources.Requirement;
import org.eclipse.lyo.client.oslc.resources.RmConstants;
import org.eclipse.lyo.client.oslc.resources.RmUtil;
import org.eclipse.lyo.oslc4j.core.model.Link;
import org.eclipse.lyo.oslc4j.core.model.ResourceShape;

/**
 * This example demonstrates how to create a requirement resource using the OSLC4J APIs
 *  
 * A Jazz Team server must be started.
 * 
 * Updated for RM v4.0 to add folder support.
 */
public class Example03 {
	String server;
	JazzRootServicesHelper helper;
	OslcOAuthClient oslcClient;
	String projectAreaName;
	protected String JTS_Server;
	Float version;
		
	Example03(String server, String jts, String login, String password, String projectAreaName, float version) {
		super();
		this.server = server;
		
		try {
			//Initialize a Jazz rootservices helper and indicate we're looking for the RequirementManagement catalog
			// The root services for DOORs is found at /public level
			helper = new JazzRootServicesHelper(server, OSLCConstants.OSLC_RM_V2);
			
			//Create a new OSLC OAuth capable client, the parameter of following call should be provided
			// by the system administrator of the RRC/DNG server
			OslcOAuthClient client = helper.initOAuthClient("123", "1234567890");
			
			if (client == null) {
				System.out.print(">> login failed.");
				System.exit(-1);
			}
				
			//Try to access the context URL to trigger the OAuth dance and login
			try {
				client.getResource(server, OSLCConstants.CT_RDF);
			} catch (OAuthRedirectException oauthE) {
				HttpUtils.validateTokens(client,  oauthE.getRedirectURL() + "?oauth_token=" + oauthE.getAccessor().requestToken, login, password, jts + "/j_security_check" );
				// Try to access again
				ClientResponse response = client.getResource(server, OSLCConstants.CT_RDF);
				response.getEntity(InputStream.class).close();
			}
			
			this.oslcClient = client;			
			this.projectAreaName = projectAreaName;
			this.JTS_Server = jts;
			
			// make the default compatibility for this example be RM v3.0, unless overridden in main()
			try {
				this.version = version;
			} catch(Exception e){
				this.version = 3.0f;
			}
			
			return;
			
		} catch (InvalidCredentialsException e) {
			e.printStackTrace();
		} catch (RootServicesException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (OAuthException e) {
			e.printStackTrace();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		
		System.exit(-1);
	}	
	
	void run() {
		try {			
			// Step (1) : Retrieve the Service Providers catalog
			String catalogURI = helper.getCatalogUrl();
			System.out.println(">> Service Providers Catalog: "+catalogURI);
			
			// Step (2) : Retrieve the designated Service Provider (Project Area)
			String serviceProviderURI = oslcClient.lookupServiceProviderUrl(catalogURI, projectAreaName);
			System.out.println(">> Project Area ["+projectAreaName+"]: "+serviceProviderURI);
			
			// Step (3) : (Optional)  Create folders 
			// should only be used with RM Version 4.0 or above
			String baseFolder = null;
			String sourceFolderUrl = null;
			String targetFolderUrl = null;
			if (this.version >= 4.0f ) {
				System.out.println(">> Create Folder");
				baseFolder = createFolder(serviceProviderURI, "TestBaseOSLCWS", null);
				sourceFolderUrl = createFolder(serviceProviderURI, "SourceFolder", baseFolder);
				targetFolderUrl = createFolder(serviceProviderURI, "TargetFolder", baseFolder);
			}
			
			// Step (4) : Find a creation factory and create requirement
			String requirementURL = createRequirement(serviceProviderURI, sourceFolderUrl);
			System.out.println(">> Created Requirement ["+requirementURL+"]");
			
			// Step (5) : Modify the requirement we just created
			updateRequirement(requirementURL,targetFolderUrl);
			System.out.println(">> Updated Requirement ["+requirementURL+"]");
			
		}catch (Exception e){
			e.printStackTrace();
		}
		finally {
			// Shutdown the HTTP connection
			if (oslcClient != null) {
				oslcClient.getHttpClient().getConnectionManager().shutdown();
			}
		}
	}

	public static void main(String[] args) throws Exception {
		//============== Code to adapt to your own configuration =============//
		String server = "https://localhost:9443/rm";		// Set the Public URI of your RRC server
		String JTS_Server = "https://localhost:9443/jts"; //Set the public URI of your JTS server
		String login = "HDHOKIY";									// Set the user login 
		String password = "HDHOKIY";								// Set the associated password
		String projectName = "OSLC Demo (RM)";
		float version = (float) 4.0;   // specify the version of the RM server
		//============== -------------------------------------- =============//
		
		new Example03(server, JTS_Server, login, password, projectName,version).run();
	}
	
	private String createRequirement(String serviceProviderUrl,String parentFolderUrl) throws Exception {
		//Get the Creation Factory URL
		Requirement requirement = new Requirement();
		String requirementFactory = oslcClient.lookupCreationFactory(
				serviceProviderUrl, OSLCConstants.OSLC_RM_V2,
				requirement.getRdfTypes()[0].toString());
		
		//Get Requirement Requirement Type URL
		// Be sure to choose an artifact type that exists in your Sample project area. We used Feature because that exists
		// in the JKE Banking (Requirements Management) sample
		ResourceShape featureInstanceShape = RmUtil.lookupRequirementsInstanceShapes(
				serviceProviderUrl, OSLCConstants.OSLC_RM_V2,
				requirement.getRdfTypes()[0].toString(), oslcClient, "Feature");
		
		//For this example, lets assume we just want to have a title, description and 
		//some basic content to add to primary text.
		requirement.setInstanceShape(featureInstanceShape.getAbout());
		requirement.setTitle("MyDocument");
		requirement.setDescription("This is a test document");
		
		//Note: primary text must be in xhtml compliant format
		String primaryText = "<div xmlns=\"http://www.w3.org/1999/xhtml\" id=\"_Nf2cQJKNEd25PMUBGiN3Dw\"><h1 id=\"_DwpWsMueEd28xKN9fhQheA\">Test Document</h1></div>";
		org.w3c.dom.Element obj = RmUtil.convertStringToHTML(primaryText);
		
		requirement.getExtendedProperties().put(RmConstants.PROPERTY_PRIMARY_TEXT, obj);
		
		if (parentFolderUrl != null) {
			requirement.getExtendedProperties().put(RmConstants.PROPERTY_PARENT_FOLDER,
					                                new URI(parentFolderUrl));
		}
		
		//Post to the Requirement Factory
		ClientResponse response = oslcClient.createResource(requirementFactory, requirement,
				OSLCConstants.CT_RDF,
				OSLCConstants.CT_RDF);

		String requirementLocation = response.getHeaders().getFirst("Location");
		
		response.consumeContent();
		
		return requirementLocation;
	}
	
	// New folder functionality for RM Server version 4.0 and above
	private String createFolder(String serviceProviderUrl, String folderName, String parentfolder) throws Exception {
		// Get the Project ID
		String projectID = serviceProviderUrl.substring(0, serviceProviderUrl.lastIndexOf("/"));
		projectID = projectID.substring(projectID.lastIndexOf("/") + 1);
		
		if ( folderName == null)
			folderName = "OSLC Created";
		
		if ( parentfolder == null ) {
			//lets create it on the root
			parentfolder = this.server + "/folders/" + projectID; 
		}
		
		// 6.0 update - changed to using rm server for targetProject URL, not the JTS server
		// Create the URL Creation factory
		String targetProject = "?projectURL=" + this.server + "/process/project-areas/" + projectID; 
		String folderCreationFactory = this.server + "/folders" + targetProject;
		
		// Create the body content
		Folder folder = new Folder();
		
		folder.setTitle(folderName);
		folder.setParent(new URI(parentfolder));
		
		ClientResponse response = oslcClient.createResource(folderCreationFactory, folder,
															OSLCConstants.CT_XML,
															OSLCConstants.CT_XML);
		
		String folderLocation = response.getHeaders().getFirst("Location");
		
		response.consumeContent();
		
		return folderLocation;
	}	
	
	private void updateRequirement(String requirementURL,String parentfolder) throws Exception {
		Thread.sleep(3000); //wait for indexing
		
		//Get the document we just created
		ClientResponse response = oslcClient.getResource(requirementURL, OSLCConstants.CT_RDF);
		
		if (response.getStatusCode() != 200) {
			response.consumeContent();
			throw new HttpResponseException(response.getStatusCode(),
					response.getMessage());
		}
		
		Requirement requirement = response.getEntity(Requirement.class);
		List<String> etagValues = response.getHeaders().get("etag");
		
		Link implementedBy = new Link(new URI("http://www.ibm.com"));
		requirement.setImplementedBy(new Link[] { implementedBy });
		
		response = etagValues != null ? 
				oslcClient.updateResource(requirementURL, requirement, OSLCConstants.CT_RDF,
						                  OSLCConstants.CT_RDF,
										  etagValues.get(etagValues.size() - 1)) :				
				oslcClient.updateResource(requirementURL, requirement, OSLCConstants.CT_RDF,
										  OSLCConstants.CT_RDF);
				
		response.consumeContent();
		
		if (response.getStatusCode() != 200) {
			response.consumeContent();
			throw new HttpResponseException(response.getStatusCode(),
					response.getMessage());
		}
		//If we get here then our PUT succeeded and the requirement should have our link now
	}
}
