/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2010, 2013, 2016 All Rights Reserved. 
 * 
 * Note to U.S. Government Users Restricted Rights:  Use, 
 * duplication or disclosure restricted by GSA ADP Schedule 
 * Contract with IBM Corp.
 *******************************************************************************/
package net.jazz.oslc.consumer.examples;

import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;

import net.jazz.oslc.utils.HttpUtils;
import net.oauth.OAuthException;

import org.apache.http.auth.InvalidCredentialsException;
import org.apache.http.client.ClientProtocolException;
import org.apache.wink.client.ClientResponse;
import org.eclipse.lyo.client.exception.RootServicesException;
import org.eclipse.lyo.client.oslc.OAuthRedirectException;
import org.eclipse.lyo.client.oslc.OSLCConstants;
import org.eclipse.lyo.client.oslc.OslcOAuthClient;
import org.eclipse.lyo.client.oslc.jazz.JazzRootServicesHelper;
import org.eclipse.lyo.oslc4j.core.model.ServiceProvider;
import org.eclipse.lyo.oslc4j.core.model.ServiceProviderCatalog;

/**
 * This example describes using an OAuth authentication mechanism of the OSLC4J
 * APIs to access the Service Providers catalog and list the Service Providers currently available.
 * 
 * A Jazz Team server must be started.
 */
public class Example02 {

	public static void main(String[] args) {
		//============== Code to adapt to your own configuration =============//
		String server = "https://localhost:9443/rm";		// Set the Public URI of your RRC server
		String JTS_Server = "https://localhost:9443/jts"; //Set the public URI of your JTS server
		String login = "HDHOKIY";									// Set the user login 
		String password = "HDHOKIY";								// Set the associated password
		//============== -------------------------------------- =============//
		
		System.out.println(">> Example02: Print out the content of the Service Providers catalog");
		System.out.println("	- Login: "+login);
		System.out.println("	- Password: "+password);

		OslcOAuthClient client = null;
		try {
			//Initialize a Jazz rootservices helper and indicate we're looking for the RequirementManagement catalog
			// The root services for DOORs is found at /public level
			JazzRootServicesHelper helper = new JazzRootServicesHelper(server, OSLCConstants.OSLC_RM_V2);
			
			//Create a new OSLC OAuth capable client, the parameter of following call should be provided
			// by the system administrator of the RRC/DNG server
			client = helper.initOAuthClient("123", "1234567890");
			
			if (client == null) {
				System.out.print(">> login failed.");
				return;
			}
				
			//Try to access the context URL to trigger the OAuth dance and login
			try {
				client.getResource(server, OSLCConstants.CT_RDF);
			} catch (OAuthRedirectException oauthE) {
				HttpUtils.validateTokens(client,  oauthE.getRedirectURL() + "?oauth_token=" + oauthE.getAccessor().requestToken, login, password, JTS_Server + "/j_security_check" );
				// Try to access again
				ClientResponse response = client.getResource(server, OSLCConstants.CT_RDF);
				response.getEntity(InputStream.class).close();
			}
			
			//Fetch the catalog of service providers.
			ClientResponse response = client.getResource(helper.getCatalogUrl(), OSLCConstants.CT_RDF);
			ServiceProviderCatalog catalog = response.getEntity(ServiceProviderCatalog.class);
			
			if (catalog != null) {
				for (ServiceProvider sp : catalog.getServiceProviders()) {
					System.out.println(">> \t - "+ sp.getTitle());
				}
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InvalidCredentialsException e) {
			e.printStackTrace();
		} catch (RootServicesException e) {
			e.printStackTrace();
		} catch (OAuthException e) {
			e.printStackTrace();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		} finally {
			if (client != null) {
				client.getHttpClient().getConnectionManager().shutdown();
			}
		}
	}

}
