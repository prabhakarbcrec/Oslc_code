/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2010, 2013,2016. All Rights Reserved. 
 * 
 * Note to U.S. Government Users Restricted Rights:  Use, 
 * duplication or disclosure restricted by GSA ADP Schedule 
 * Contract with IBM Corp.
 *******************************************************************************/
package net.jazz.oslc.consumer.examples;

import java.io.IOException;
import java.net.URISyntaxException;

import net.jazz.oslc.utils.HttpUtils;
import net.oauth.OAuthException;

import org.apache.http.client.ClientProtocolException;
import org.apache.wink.client.ClientResponse;
import org.eclipse.lyo.client.oslc.OslcClient;

/**
 * This first example describes how to access to the Root Services document
 * (https://localhost:9443/jazz/rootservices) using the OSLC4J client APIs
 * 
 * A Jazz Team server must be started.
 */
public class Example01 {

	public static void main(String[] args) {
		//============== Code to adapt to your own configuration =============//
		String server = "https://localhost:9443/rm";		// Set the Public URI of your RRC server
		//============== -------------------------------------- =============//
		
		String rootServices = server + "/rootservices";
		System.out.println(">> Example01: Accessing Root Services document with HttpClient");
		System.out.println("	- Root Services URI: "+rootServices);

		// Setup the OslcClient
		OslcClient oslcClient = new OslcClient();
		
		ClientResponse response;
		try {
			// Execute the request
			response = oslcClient.getResource(rootServices, "application/rdf+xml");
			System.out.println(">> HTTP Status code:" + response.getStatusCode());
			
			if (response.getStatusCode() == 200) {
				System.out.println(">> HTTP Response Headers: ");
				HttpUtils.printResponseHeaders(response);
				
				System.out.println(">> HTTP Response Body: ");
				HttpUtils.printResponseBody(response);
			} else {			
				// Release allocated resources
				response.consumeContent();
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (OAuthException e) {
			e.printStackTrace();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		} finally {
			// Shutdown the HTTP connection
			if (oslcClient != null) {
				oslcClient.getHttpClient().getConnectionManager().shutdown();
			}
		}
	}

}
