/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2011,2014,2016. All Rights Reserved. 
 * 
 * Note to U.S. Government Users Restricted Rights:  Use, 
 * duplication or disclosure restricted by GSA ADP Schedule 
 * Contract with IBM Corp.
 *******************************************************************************/
package net.jazz.oslc.consumer.examples;

import net.jazz.oslc.utils.HttpUtils;

import org.apache.wink.client.ClientResponse;
import org.eclipse.lyo.client.oslc.OSLCConstants;
import org.eclipse.lyo.client.oslc.resources.OslcQuery;
import org.eclipse.lyo.client.oslc.resources.OslcQueryParameters;
import org.eclipse.lyo.client.oslc.resources.OslcQueryResult;

/**
 * This example demonstrates how to query for a requirement resource using the OSLC4J APIs
 * 
 * A Jazz Team server must be started.
 */
public class Example04 extends Example03 {

	Example04(String server, String jts, String login, String password,
			String projectAreaName, float version) {
		super(server, jts, login, password, projectAreaName, version);
	}

	void run() {
		try {			
			// Step (1) : Retrieve the Service Providers catalog
			String catalogURI = helper.getCatalogUrl();
			System.out.println(">> Service Providers Catalog: "+catalogURI);
			
			// Step (2) : Retrieve the designated Service Provider (Project Area)
			String serviceProviderURI = oslcClient.lookupServiceProviderUrl(catalogURI, projectAreaName);
			System.out.println(">> Project Area ["+projectAreaName+"]: "+serviceProviderURI);
			
			// Step (3) : Find the query capability element in the service provider document
			String queryCapabilityURI = oslcClient.lookupQueryCapability(serviceProviderURI,
					  OSLCConstants.OSLC_RM_V2,
					  OSLCConstants.RM_REQUIREMENT_TYPE);
			
			// Step (4) : Perform query operation
			performQuery(queryCapabilityURI);
						
		}catch (Exception e){
			e.printStackTrace();
		}
		finally {
			// Shutdown the HTTP connection
			if (oslcClient != null) {
				oslcClient.getHttpClient().getConnectionManager().shutdown();
			}
		}
	}
	
	private void performQuery(String queryCapabilityURI) throws Exception
	{
		// Query by Identifier
		// for this example, pick an id that you know exists in the project that you are using
		String identifier = "16";
		OslcQueryParameters queryParams = new OslcQueryParameters();
		
		queryParams.setPrefix("dcterms=<http://purl.org/dc/terms/>");
		queryParams.setWhere("dcterms:identifier=" + identifier);
		queryParams.setSelect("dcterms:title,dcterms:identifier");
		
		OslcQuery query = new OslcQuery(oslcClient, queryCapabilityURI, 10, queryParams);
		
		OslcQueryResult result = query.submit();
		ClientResponse response = result.getRawResponse();
		
		if (response.getStatusCode() != 200) {
			response.consumeContent();
			System.out.println(response.getMessage());
		} else {
			HttpUtils.printResponseBody(response);
		}
	}

	public static void main(String[] args) throws Exception {
		//============== Code to adapt to your own configuration =============//
		String server = "https://localhost:9443/rm";		// Set the Public URI of your RRC server
		String JTS_Server = "https://localhost:9443/jts"; //Set the public URI of your JTS server
		String login = "HDHOKIY";									// Set the user login 
		String password = "HDHOKIY";								// Set the associated password
		String projectName = "OSLC Demo (RM)";
		float version = (float) 4.0;   // specify the version of the RM server, if no version specified, the default is 3.0
		//============== -------------------------------------- =============//
		
		new Example04(server, JTS_Server, login, password, projectName,version).run();
	}
	
}
