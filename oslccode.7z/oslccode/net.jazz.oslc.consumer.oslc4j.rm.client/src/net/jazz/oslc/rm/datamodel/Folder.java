/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2013. All Rights Reserved. 
 * 
 * Note to U.S. Government Users Restricted Rights:  Use, 
 * duplication or disclosure restricted by GSA ADP Schedule 
 * Contract with IBM Corp.
 *******************************************************************************/
package net.jazz.oslc.rm.datamodel;

import java.net.URI;
import java.net.URISyntaxException;

import org.eclipse.lyo.client.oslc.resources.RmConstants;
import org.eclipse.lyo.oslc4j.core.annotation.OslcDescription;
import org.eclipse.lyo.oslc4j.core.annotation.OslcName;
import org.eclipse.lyo.oslc4j.core.annotation.OslcNamespace;
import org.eclipse.lyo.oslc4j.core.annotation.OslcOccurs;
import org.eclipse.lyo.oslc4j.core.annotation.OslcPropertyDefinition;
import org.eclipse.lyo.oslc4j.core.annotation.OslcResourceShape;
import org.eclipse.lyo.oslc4j.core.annotation.OslcTitle;
import org.eclipse.lyo.oslc4j.core.annotation.OslcValueType;
import org.eclipse.lyo.oslc4j.core.model.AbstractResource;
import org.eclipse.lyo.oslc4j.core.model.Occurs;
import org.eclipse.lyo.oslc4j.core.model.OslcConstants;
import org.eclipse.lyo.oslc4j.core.model.ValueType;


@OslcNamespace(RmConstants.JAZZ_RM_NAV_NAMESPACE)
@OslcResourceShape(title = "Requirement Folder Shape", describes = RmConstants.JAZZ_RM_NAV_NAMESPACE + "folder")
@OslcName("folder")
public final class Folder
	extends AbstractResource
{
	// The only extra field is uses
	private String title;;
	private URI      parent;

    public Folder()
           throws URISyntaxException
    {
        super();
    }

    public Folder(final URI about)
           throws URISyntaxException
    {
        super(about);
    }
        
    @OslcDescription("The folder's parent.")
    @OslcPropertyDefinition(RmConstants.JAZZ_RM_NAV_NAMESPACE + "parent")
    @OslcTitle("Parent")
    public URI getParent()
    {
        return parent;
    }

    @OslcDescription("Title (reference: Dublin Core) or often a single line summary of the resource represented as rich text in XHTML content.")
    @OslcOccurs(Occurs.ExactlyOne)
    @OslcPropertyDefinition(OslcConstants.DCTERMS_NAMESPACE + "title")
    @OslcTitle("Title")
    @OslcValueType(ValueType.XMLLiteral)
    public String getTitle()
    {
        return title;
    }
        
    public void setParent(final URI parent)
    {
        this.parent = parent;
    }
    
    public void setTitle(final String title)
    {
        this.title = title;
    }
}
